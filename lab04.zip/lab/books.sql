DROP TABLE IF EXISTS books
CREATE TABLE books (id INT(4) NOT NULL AUTO_INCREMENT PRIMARY KEY, bookname VARCHAR(30), authors VARCHAR(100), price FLOAT(8.3))
INSERT INTO books (bookname, authors, price) VALUES ( "AWS ACF", "Yeh CT and Chen HS", 628.0), ( "ESP32-CAM and AWS", "Yeh CT", 650)