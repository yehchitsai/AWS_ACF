from flask import  Flask,render_template,request,redirect,jsonify
import json
import os

cmds = {
  'CPUIdle': '/usr/bin/vmstat 1 2 | /usr/bin/awk \'{ for (i=1; i<=NF; i++) if ($i=="id") { getline; getline; print $i }}\'',
  'Id': 'TOKEN=`/usr/bin/curl -X PUT "http://169.254.169.254/latest/api/token" -H "X-aws-ec2-metadata-token-ttl-seconds: 21600"` && /usr/bin/curl -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/instance-id',
  'AZ': 'TOKEN=`/usr/bin/curl -X PUT "http://169.254.169.254/latest/api/token" -H "X-aws-ec2-metadata-token-ttl-seconds: 21600"` && /usr/bin/curl -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/placement/availability-zone'
}

app=Flask(__name__)

def runCommand(cmd):
  stream = os.popen(cmd)
  result = stream.read().strip()
  return result
  
@app.route("/")
def index():
  dic={}
  for k,v in cmds.items():
    output = runCommand(v)
    dic[k] = output
  
  print(dic)

  return render_template('cpu_info.html', info = dic)

@app.route('/load',methods=['GET'])
def loadUp():
  cmd = '/usr/bin/dd if=/dev/zero bs=100M count=500 | gzip | gzip -d  > /dev/null &'
  runCommand(cmd)
  return redirect('/')

if __name__=='__main__':
  app.run(host='0.0.0.0', port=80, debug=True)

