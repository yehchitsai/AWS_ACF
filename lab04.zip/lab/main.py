from flask import  Flask,render_template,request,redirect,jsonify
import pymysql
import json

cfgFile = 'rds.cfg'
(READY, NOTYET) = (0,1)
status=NOTYET

db = None

def connectDB():
  global db
  try:
    f = open(cfgFile,'r')
    s = f.read()
    rdsCFG = json.loads(s)
    db = pymysql.connect(host = rdsCFG["RDS_URL"],
      user = rdsCFG["RDS_user"],
      password = rdsCFG["RDS_pwd"],
      database = rdsCFG["RDS_DB"])
  except Exception as e:
    print(e)
    return None

  return db

app=Flask(__name__)

@app.route("/")
def index():
  global db
  results = {}

  try:
    db = connectDB()
    cursor = db.cursor()
    query = "select * from books"
    cursor.execute(query)
    results = cursor.fetchall()
    res = []
    for rec in results:
      dic = {'id':rec[0], 'bookname':rec[1], 'authors': rec[2], 'price': rec[3]}
      res.append(dic)
  
    db.close()
    status=READY
  except Exception as e:
    print(e)
    status=NOTYET

  if status==NOTYET: # show RDS config form
    print('input RDS information')
    return render_template('rds_config.html')
  else:# show rds table
    contentFile = 'book_op.html'
    return render_template('book_op.html', res = res)

@app.route('/bookdel/<int:id>',methods=['DELETE'])
def delete_book(id):
  sql='delete from books where id=%s'%(id)
  print(sql)
  db = connectDB()
  cursor = db.cursor()
  res = cursor.execute(sql)
  db.commit()
  db.close()
  return jsonify({'res':res})

@app.route('/bookadd',methods=['POST'])
def create_book():
  authorname=request.form.get('authors')
  bookname=request.form.get('bookname')
  bookprice=request.form.get('price') # bookname, authors, price
  sql = 'INSERT INTO books (authors, bookname, price) values("{0}","{1}",{2})'.format(authorname, bookname, bookprice)
  db = connectDB()
  cursor = db.cursor()
  res = cursor.execute(sql)
  db.commit()
  db.close()
  return redirect('/')

@app.route("/rdsWriteConfig", methods = ['POST'])
def writeConfig():
  rdsCFG = { 
    "RDS_URL" : request.form.get('endpoint'),
    "RDS_DB"  : request.form.get('database'), 
    "RDS_user": request.form.get('username'), 
    "RDS_pwd" : request.form.get('password')
  }
  try: 
    db = pymysql.connect(host = rdsCFG["RDS_URL"],
      user = rdsCFG["RDS_user"],
      password = rdsCFG["RDS_pwd"],
      database = rdsCFG["RDS_DB"])
    cursor = db.cursor()
    # import SQL text file to MySQL
    sqlFile = open('books.sql','r')
    # read file using for loop
    for line in sqlFile:
      cursor.execute(line)

    db.commit()
    # write RDS config to file
    f = open(cfgFile,'w')
    s = json.dumps(rdsCFG)
    f.write(s)
    message = "return to main page"
    db.close()
    sqlFile.close()
    f.close()
    return redirect('/')
  except Exception as e:
    message = str(e)

  return message

if __name__=='__main__':
  app.run(host='0.0.0.0', port=80, debug=True)

